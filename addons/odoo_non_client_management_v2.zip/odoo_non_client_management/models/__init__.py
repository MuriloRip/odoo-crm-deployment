from . import res_partner
from . import non_client_transaction
